import "@hotwired/turbo-rails";
import * as bootstrap from "bootstrap/dist/js/bootstrap"
import Rails from "@rails/ujs";
Rails.start();
