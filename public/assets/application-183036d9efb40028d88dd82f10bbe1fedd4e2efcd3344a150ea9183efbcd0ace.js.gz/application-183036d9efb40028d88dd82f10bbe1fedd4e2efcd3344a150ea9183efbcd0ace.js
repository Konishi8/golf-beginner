import "@hotwired/turbo-rails";
import * as bootstrap from "bootstrap";
