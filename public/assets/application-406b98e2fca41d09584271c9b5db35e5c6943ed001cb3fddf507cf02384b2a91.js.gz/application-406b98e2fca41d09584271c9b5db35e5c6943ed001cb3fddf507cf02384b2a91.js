import "@hotwired/turbo-rails";
import * as bootstrap from "bootstrap/dist/js/bootstrap";
